Hi there,

The CTF is is pretty much simple analyze the binary file and crack the ctf
this is a problem of reverse engineering with a file named "rev_this".
